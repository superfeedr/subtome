=== Widget Name ===

Contributors: julien51
Donate link: http://www.subtome.com/
Tags: widget, subscribe, subscription, subtome
Requires at least: 3.3.1
Tested up to: 3.3.1
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This publish adds a SubToMe widget to your blog and allows people
to subscribe to your content in one click.

== Description ==

This widget adds a [SubToMe](http://www.subtome.com/) button to your Wordpress blog. This button allows your readers to follow your blog using their **favorite** applications.

== Installation ==

1. Upload the plugin directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
2. Add the widget to your layout from the 'Widget' submenu in WordPress

== Credits ==

[Wordpress Widget Boilerplate](https://github.com/tommcfarlin/WordPress-Widget-Boilerplate)

== Changelog ==

= 1.0 =
* First version
