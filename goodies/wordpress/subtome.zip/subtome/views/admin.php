<p>
  <label>Title:<br />
    <input name="subtome_title" type="text" value="<?php echo $options['title']; ?>" />
  </label>
</p>
<p>
  <label>Button Label:<br />
    <input name="subtome_caption" type="text" value="<?php echo $options['caption']; ?>" />
  </label>
</p>
