<?php if(isset($options['title']) && $options['title'] != "") { ?>
  <h3 class="widget-title"><?php echo $options['title']; ?></h3>
<?php } ?>
<input type="button" onclick="(function(){var z=document.createElement('script');z.src='https://s3.amazonaws.com/www.subtome.com/load.js';document.body.appendChild(z);})()" value="<?php echo $options['caption']; ?>">
